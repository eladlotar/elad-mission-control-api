# ELAD Mission Control API (Starter)

Basic Node/Express server for Render deployment.
